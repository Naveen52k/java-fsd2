
public class object {
	
	public static void main(String[] args) {
        
        Person person1 = new Person("Alice", 30);
        Person person2 = new Person("Bob", 25);

        System.out.println("Person 1's name: " + person1.name);
        System.out.println("Person 2's age: " + person2.age);
        
        person1.displayInfo();
        person2.displayInfo();
	}
}
