
public class trycatch {

	public static void main(String[] args) {
		try {
            int[] numbers = { 1, 2, 3, 4};
            int index = 8;
            int result = numbers[index];
            System.out.println("Result: " + result);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("An ArrayIndexOutOfBoundsException occurred.");
        }

        System.out.println("Program continues after the try-catch block.");
	
	}

}
