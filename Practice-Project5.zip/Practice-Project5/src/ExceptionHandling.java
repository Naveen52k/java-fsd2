import java.rmi.AccessException;

@SuppressWarnings("serial")
class CustomException extends AccessException {
    public CustomException(String message) {
        super(message);
    }

	public String getMessage() {
		// TODO Auto-generated method stub
		return null;
	}
}

public class ExceptionHandling {
    public static void main(String[] args) {
        try {
            int[] numbers = { 1, 2, 3, 4, 5, 5 };
            int index = 9;
            @SuppressWarnings("unused")
			int result = divideNumbers(numbers, index);
        } catch (Exception e) {
            System.out.println("Custom Exception caught: " + e.getMessage());
        } finally {
            System.out.println("This block always gets executed.");
        }
    }

    public static int divideNumbers(int[] numbers, int index) throws Exception {
        try {
            if (index < 0 || index >= numbers.length) {
                throw new ArrayIndexOutOfBoundsException("Index is out of bounds.");
            }
            int result = numbers[index] / numbers[index - 1];
            if (result == 0) {
                throw new ArithmeticException("Division by zero is not allowed.");
            }
            return result;
        } catch (ArithmeticException e) {
            throw new Exception("Exception: " + e.getMessage());
        }
    }
}
