
import java.io.*;

public class filehandling {
	
    public static void main(String[] args) {
        try {
       
            String filePath = "sample.txt";

         
            FileWriter writer = new FileWriter(filePath);
            writer.write("Simplilearn trains freshers in Mphasis");
            writer.close();

            
            FileReader reader = new FileReader(filePath);
            int character;
            while ((character = reader.read()) != -1) {
                System.out.print((char) character);
            }
            reader.close();

        
            FileWriter appendWriter = new FileWriter(filePath, true);
            appendWriter.write("This text is appended.\n");
            appendWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

