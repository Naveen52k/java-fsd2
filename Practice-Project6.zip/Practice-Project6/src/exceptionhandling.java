
public class exceptionhandling {
    @SuppressWarnings("unused")
	public static void main(String[] args) {
        try {
            
            int result = 5 / 3;
            
            int[] arr = {1, 2, 3};
            int value = arr[3];
            
            String str = null;
            @SuppressWarnings("null")
			int length = str.length();
        } catch (ArithmeticException e) {
            System.out.println("Arithmetic Exception caught: " + e.getMessage());
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array Index Out of Bounds Exception caught: " + e.getMessage());
        } catch (NullPointerException e) {
            System.out.println("Null Pointer Exception caught: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Generic Exception caught: " + e.getMessage());
        } finally {
            System.out.println("Finally block always gets executed.");
        }

        System.out.println("Program continues after exception handling.");
    }
}
