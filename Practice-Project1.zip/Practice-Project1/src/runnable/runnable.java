package runnable;
class MyRunnable implements runnable {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Thread using Runnable interface: " + i);
        }
    }
}

public interface runnable {

}
