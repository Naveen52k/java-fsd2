import runnable.runnable;

class MyRunnable implements runnable {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Thread using Runnable interface: " + i);
        }
    }
    
public class Runnable {
    public Runnable(Runnable runnable) {
		
	}



	public static void main(String[] args) {
        Runnable runnable = new Runnable();
        Runnable thread1 = new Runnable(runnable);
        Runnable thread2 = new Runnable(runnable);

        thread1.start();
        thread2.start();
    }

	private void start() {
		// TODO Auto-generated method stub
		

	}
}
}


