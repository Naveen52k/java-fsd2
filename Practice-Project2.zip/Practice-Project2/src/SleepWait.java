
public class SleepWait {

	public static void main(String[] args) {
		final Object lock = new Object();
		Thread thread1 = new Thread(() -> {
			synchronized (lock) {
				System.out.println("Naveen is running.");
				try {
					Thread.sleep(4000); // Sleep for 2 seconds
					} catch (InterruptedException e) {
						e.printStackTrace();
						}
				System.out.println("Naveen is done.");
				lock.notify(); // Notify waiting threads
				}
			});
		Thread thread2 = new Thread(() -> {
			synchronized (lock) {
				System.out.println("Naveen is resting.");
				try {
					lock.wait(); // Wait until notified by Thread 1
					} catch (InterruptedException e) {
						e.printStackTrace();
						}
				System.out.println("Naveen is getting refreshed.");
		            }
			});
		thread1.start();
		thread2.start();
		}

}
