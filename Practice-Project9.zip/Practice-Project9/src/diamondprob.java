
interface Human {
    void eat();
}

class person implements Human {
    @Override
    public void eat() {
        System.out.println("person eats food.");
    }

    void walk() {
        System.out.println("person walks.");
    }
}

class person1 implements Human {
    @Override
    public void eat() {
        System.out.println("person1 eats liquid item.");
    }

    void speak() {
        System.out.println("person1 speaks.");
    }
}

class human implements Human {
    @Override
    public void eat() {
        System.out.println("human eats something.");
    }
}

public class diamondprob{
    public static void main(String[] args) {
        person Person = new person();
        Person.eat();
        Person.walk();

        person1 Person1 = new person1();
        Person1.eat();
        Person1.speak();

        human Human = new human();
        Human.eat();
    }
}

