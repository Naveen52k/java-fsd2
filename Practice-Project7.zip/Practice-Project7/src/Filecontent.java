import java.io.Writer;

class Filecontent {

	public Writer append(String line) {
		// TODO Auto-generated method stub
		return null;
	}

}
