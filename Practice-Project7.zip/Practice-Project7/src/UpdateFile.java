import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class UpdateFile {
	 public static void appendToFile(String filePath, String data) {
	        try (FileWriter writer = new FileWriter(filePath, true);
	             BufferedWriter bufferedWriter = new BufferedWriter(writer)) {
	            bufferedWriter.write(data);
	            System.out.println("Data appended to the file.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while appending to the file.");
	            e.printStackTrace();
	        }
	    }

}
