import java.io.File;

public class DeleteFile {

    public static void deleteFile(String filePath) {
        File file = new File(filePath);
        if (file.delete()) {
            System.out.println("File deleted: " + filePath);
        } else {
            System.out.println("File could not be deleted.");
        }
        deleteFile(filePath);
        
    }

}
