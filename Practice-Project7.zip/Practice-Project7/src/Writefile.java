import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Writefile {
	 public static void writeToFile(String filePath, String data) {
	        try (FileWriter writer = new FileWriter(filePath);
	             BufferedWriter bufferedWriter = new BufferedWriter(writer)) {
	            bufferedWriter.write(data);
	            
	            writeToFile(filePath, "Hello, World!");
	            
	            System.out.println("Data written to the file.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while writing to the file.");
	            e.printStackTrace();
	        }
	    }

}
