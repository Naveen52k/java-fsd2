import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;

@SuppressWarnings("unused")
public class crud {
    public static void main(String[] args) {

        String filePath = "myFile.txt";


        createFile(filePath);


        writeToFile(filePath, "Hello, World!");


        String fileContent = readFromFile(filePath);
        System.out.println("File Content: " + fileContent);

        appendToFile(filePath, "\nThis is an appended line.");

        fileContent = readFromFile(filePath);
        System.out.println("Updated File Content: " + fileContent);

        deleteFile(filePath);
    }

	private static void deleteFile(String filePath) {
		
	}

	private static void appendToFile(String filePath, String string) {
		// TODO Auto-generated method stub
		
	}

	private static String readFromFile(String filePath) {
		// TODO Auto-generated method stub
		return null;
	}

	private static void writeToFile(String filePath, String string) {
		// TODO Auto-generated method stub
		
	}

	private static void createFile(String filePath) {
		// TODO Auto-generated method stub
		
	}

    
}
