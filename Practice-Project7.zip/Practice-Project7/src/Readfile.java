import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Readfile {

public static String readFromFile(String filePath) {
        Filecontent filecontent = new Filecontent();
        
   	 filecontent = readFromFile(filePath);
     System.out.println("Updated File Content: " + filecontent);
     
        try (FileReader reader = new FileReader(filePath);
             BufferedReader bufferedReader = new BufferedReader(reader)) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                filecontent.append(line).append("\n");
            }
        } catch (IOException e) {
        	

             
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
        return filecontent.toString();
    }

}